import os
import openai
import uuid
from sklearn.metrics.pairwise import cosine_similarity
import time

# Your credentials here.
openai.organization = "org-PSlM10cRMQXx9N1Ogi3l7ino"
openai.api_key = "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"


def retry_openai_request(fn, max_retries=5):
    for attempt in range(max_retries):
        try:
            return fn()
        except Exception as e:
            if attempt < max_retries - 1:  # i.e. if it's not the final attempt
                print(f"Retrying request... (Attempt {attempt + 2})")
                time.sleep(1)  # Wait for a second before making the next call
                continue
            else:
                raise e

def split_text_into_chunks(text, chunk_size=300):
    words = text.split()
    return [' '.join(words[i:i+chunk_size]) for i in range(0, len(words), chunk_size)]

def create_embedding(chunk):
    def make_request():
        return openai.Embedding.create(
            input=chunk,
            model="text-embedding-ada-002"
        )
    response = retry_openai_request(make_request)
    return response["data"][0]["embedding"]

def create_query_embedding(query):
    def make_request():
        return openai.Embedding.create(
            input=query,
            model="text-embedding-ada-002"
        )
    response = retry_openai_request(make_request)
    return response["data"][0]["embedding"]

print("Initializing text...")
text = """Jasper: "Hi, bed. Like."
          Patrick: "Hey, how are you doing?"
          Jasper: "I'm doing great. I see your face now, I have an idea to who I'm talking to."
          Patrick: "Yeah, I'm in the office today."
          Jasper: "Nice. How are you doing?"
          Patrick: "Doing all right. You have the last meeting of the day, so."
          Jasper: "Okay. And then you're gonna go off and enjoy the weekend or not?"
          Patrick: "Well, today, it's time to leave after this call. Yes, usually not, but this day was a
          typical Friday. So whatever that means…"
          Jasper: "Was was busy or just random?"
          Patrick: "Just busy on random bullshit topics, so."
          Jasper: "Yeah, yeah, yeah. Like like this call or?"
          Patrick: "This is probably the only call that is okay for today, but it depends on you, right?
          So, depends on."
          Jasper: "That's great. Yeah, I have to prove it to you, right? Yeah. Now, do you already have
          any fun, we get plans?"
          Patrick: "Work. So I work alto tomorrow. So you have a few issues that we need to solve,
          but."
          Jasper: "Is that usual for you that you work on Saturdays?"
          Patrick: "Where I'm not working for Lily. Am I usually work, for site projects? I'm…"
          Jasper: "Okay. Yeah, yeah."
          Patrick: "I try to keep myself busy."
          Jasper: "That's nice. Sounds good. All right. I already sent you quite a bunch of information,
          of course, where there are already things that you would like to have clarified before we jump
          into the product demo. And after that, the pricing overview or?"
          Patrick: "Maybe just for my understanding. So from what I got or what my assumption is at
          least for now, is that the ideal situation from work wise perspective? At least would be that
          every employee that has equipment that we need to support, put it that way has to have an
          account in your platform, a seat. Is that correct?"
          Jasper: "Exactly. Okay. Got it. However, this is not necessarily per SE because you can also
          make a division between people or MPLS who do not get a seat. Yeah, depending on how
          you would like to have, the facilitation equipments organized throughout the world. I can
          imagine that if you for example, have a quite a clear overview in Germany, you don't need
          everyone in Germany to have a seat in workplace, whereas sometimes people do need the
          equipment that you have like some flow seats in Germany for the onboarding of equipment,
          for example, whereas people working in U. S and U. K, where it's more difficult for you to
          track assets to get the onboarding going there, that you do have separate seats for those
          employees, for example. So, we can make quite a flexible division in regards to, the seats and
          work as we can also start with the number of seats and for you to see how it works with asset
          management where you want to increase it to for example, everyone. So, we can really make,
          yeah, it's a tailor, to how you would like to have that. But what was your own idea around
          this?"
          Patrick: "My own idea was that we have just a person that we can reach out to and say, hey,
          there is a new hire starting on the first of July and first name, last name, address templates
          two and email sent equipment gets sent to that person before that date, the template
          respectively then to that person… same for support and same for off balling because how it is
          done at Lydia is we have probably I assume at least you integrate with a bunch of things. I
          saw it from the slides also, I'm not sure if you integrate with workday directly, but here our
          HR is adding people into workday and from workday, a ticket gets created into service now,
          which is used for our incident and request management. And when we have that ticket, then
          we are going to start at some point creating the identity in active directory. We cannot create
          an identity before that in work rise, right? So this is connected to each other. So this is where
          I'm a little bit currently unsure how this usually works with other partners that you're doing
          this together?"
          Jasper: "So, so you're not sure how we will do this with Barnes who are having sort of the
          same workflow. Is that what you mean?"
          Patrick: "Yeah, or how the identity comes into work, right? Because, right? I don't wanna add
          it manually and it can be probably integrated with workday or so now or whatever. But."
          Jasper: "Yeah. So that would be then, the identity integration via so between Workwize and
          workday that's something that we can do, which means that everyone who is in workday
          would also automatically be assigned in Workwize, and we can even do that on the
          department level. So I assume myself that you have the templates. So for templates, you have
          a different department. I think so. Template in fact, the do is for people, in marketing
          template three for HR or however you want to make the division, probably, the templates are
          also then in workday assigned to departments. So that is also how we would directly have
          that in Workwize. But I can show you that in a minute. I've already made some ideas there."
          Patrick: "Right. That's cool."
          Jasper: "Yeah, perfect. How, sorry, quick question. Good question. We are… two and a half
          years old now almost three years old. So, so since halfway off the COVID pandemic, sure.
          Yeah. So when, of course, remote working became a challenge for a lot of companies before
          that, it was not really something."
          Patrick: "And you're so you're Dutch for sure. That's, what I, he and your company is also
          Dutch?"
          Jasper: "We are also Dutch. Yeah. So we have a office, in the nets in Amsterdam. We have
          an office in Paris for our French market, and we are also gonna open an office in New York
          quite soon for, the US markets because we are integrating with all these suppliers. We are
          having the global coverage very easily."
          Patrick: "So business is good then."
          Jasper: "It is going well. Yes, yes, for sure. But that's something I also hope to prove to you
          because I can imagine that, yeah, working with a start. You're somewhat older, right?"
          Patrick: "Hi, is now, I think seven or eight years old."
          Jasper: "Yup. Yeah. So it's quite nice that we are already supporting companies that are also
          in the stage of Liam, also corporates also listed companies, although, we are a young
          company ourselves, but we are one of the only ones who are doing it in this manner also with
          this global skill. So that's but I will show it to you. Maybe then things will become more easy
          for you, to visualize of course."
          Jasper: "I think you see my screen. Yeah. Okay, perfect. So in work wise, we basically work
          with two sides of the platform for which you can make use of. On one end, we have an admin
          site and we have an employee side, the employee sites you don't have to use. So you can do
          everything from the admin side, you can send equipment from the admin side. But if you
          want your employees to make an order or a request or something, you can also allow your
          employees to be in the employees side which I will show later. So now I will go through the
          employer side which consist of different parts. So obviously, you see the data dashboards we
          now put in data points that could be relevant for you. So for example, how much spend or
          equipment, how many users are in the platform, what the average order is, but we can of
          course customize this towards the data points that you find valuable. For example, do you
          want to see in which department things are ordered or which spending on time? We can also
          do other things here. Then I go to employee management. And how we always begin is we
          constitute the yeah, departments or, the catalogues together with you. So you already gave
          some ideas of the templates. I made an assumption that for example, template one is HR
          template tool stack quite randomly, but we can, yeah, steer it exactly towards how you would
          like to have this structured. And then employees are either invited prior the platform or we
          would integrate, with your HR tool. So meaning that everyone who's in the HR tool will also
          be in work wise. And when new employees are created an identity there, they will also have
          an identity in the Workwize platform."
          Patrick: "Is we wise integrated? Single sign on with Asher? Or how is that?"
          Jasper: "Yes. Yeah. So we also have single sign on with azure. Yeah."
          Patrick: "And I saw there is email sent or invitations, something. So a new hire obviously is
          not hired and cannot approve, or click on a link or anything like that."
          Jasper: "No. So, so, that is true. So in the case you would like to send an invitation to them,
          you can do that either via their private email to begin with. And once they get a formal
          business account, business email, then that will be switched or you say, okay, people will get
          their template items sent before their first working day. We do that via an order in the works
          platform. And once they are having, their business account, they can also get like a catalog
          with products for remote working or making it flexible themselves. So you can also do it like
          that. Usually tech teams want to send items themselves to the employees. And then the
          workplace or HR teams want their employees to, yeah, make a selection of for example chair
          desk, but that's something maybe not for your scope, right? Because."
          Patrick: "Yeah."
          Jasper: "So, so, yeah, but so we integrate with the workday and S. S. O, and then, yeah, you
          have full overview of who is in the platform. Then I go to team catalogues. And if we were to
          have a partnership together, we would put in all the products that you want to offer to you in
          please in the master catalogue. And that's the first thing you see here. So you see a master
          catalogue of, yeah, all the products, in the US, including products in Germany. And from the
          master catalogue, you can create these sub catalogue. So for example, you can say, okay, for
          template one, we only select the products that you have chosen first for template one. And
          then probably if you have template one for Germany, we would use the supplier that is in
          Germany. And for one, for the products in the us, we would use the supplier in the US to
          make sure that the shipping time is, short as possible. Of course, is that clear so far? Yeah.
          Okay. So, and of course, we would, we will make these catalogues for you and with you so
          that it's easy for you to dialect directly start working with that. Okay. So as I mentioned, you
          can also make orders for your employees and that's where you put you to as orders. So again,
          you have all the employees already in the platform. You then select the employee that is
          integrated in here. I want to load this because, I show you and because you have already pre
          signed which template or which the parts person is in, you can very easily just click, on the
          person. Then automatically, you will see which items this person would have based on their
          role. And then you select the available products or just also select everything. And then either
          you fill in the, all the information based on their home address, or if the home addresses have
          already been assigned to this person via Workwize or via workday. Then you would
          automatically send the items to our house. Does that make sense for you?"
          Patrick: "Yeah, it's different to what my current thought process was, but can we do, or can
          we go to the second point to see to select available products? How that looks like an order
          process?"
          Jasper: "Yeah, of course. So, so how is the different than your current workflow now?"
          Patrick: "It is not like, the current workflow, our current workflow is not existing, but, from
          the thought process, I had, how we could do this with other partners. It is quite different."
          Jasper: "Yeah. Okay. So, how would you see that? So, so and now I'm now sketching out
          how we can do it based on what you've said, pretty, I made as I said some assumptions. But
          yeah, we can make, the whole process totally customizable to how it is helping you. So, we
          don't have a set stone workflow we want to accommodate with your workflow and make that
          as easy as possible so that you can start working with it how you want to affect."
          Patrick: "So all, it is one one challenges and for sure, not only Liam challenge, we don't have
          standardized rules yet. And quite likely we never, we will never have that. So the assignment
          to let's say, Luther as we get there and a template for marketing, at most, we know that this
          person is in marketing, but we do not know that there because we have templates and
          everyone can have every template to be honest. So we have a template with a 13 inch
          notebook, 15 inch and whatever. So it is, we are not really templatising a user to what he can
          get. Okay. So, we are more like defining the templates and each template is a set of different
          things, a mouse, a laptop, or back, and whatever. And then we say, hey, Luther can request
          from hiring manager was Luther gets template too?"
          Jasper: "Okay. So, so the hiring manager decides which template Luther would? Okay. So
          then it's then it will get even easier. Then we don't make a template based on the department.
          Then you just say, okay, we have five templates. Every hiring manager can select the
          templates which he or she wants to send, to their colleagues. So you only click the template
          that you can then select that's also possible. Yeah. But you can even do, you can even let's
          Luther look into the employees side of the platform and let him click on the template that is
          assigned to him. That's also something you can do?"
          Jasper: "But do you then think, do you then believe that this, the workflow would be easy for
          work wise then?"
          Patrick: "Look, I think, this is the… probably the better solution than what I had in mind but
          this is a big solution. This is a big change because this would mean, hey, there, we need to
          talk with HR and who is, because in the end, this is a portal that HR can use and it doesn't
          need to give a shit, sorry language but they can have the access there and they say, hey,
          there's the new, you added someone in workday and the person comes in here automatically.
          You go in there, you get the onboarding information from the other HR, whatever team
          where you see in that kind of workflow what the hiring manager picked for Luther. And then
          you go in here and based on that information, you pick Luther, a template for let's go. So no it
          intervention at all would be needed. But in order to get that approved in the current situation
          where we are, I doubt it because this is, this would bring work to people and they don't like
          work. Let's put it that way."
          Jasper: "But don't you think okay. So, so, you say that work guys will be taking over
          basically your process of manually making orders within the it team?"
          Patrick: "Which would be better, yes."
          Jasper: "Don't you think that this would be also a solution for your team then, so that you…"
          Patrick: "100 100 percent. But then why would we do this if the right thing would be that HR
          is doing it? You see, because HR could do this and it shouldn't do this at all. Maybe."
          Jasper: "Yeah, that's something, that you should figure out indeed, whether HR so did do this
          instead of it, but what we…"
          Patrick: "Internal stuff. Yeah."
          Jasper: "But what we mainly see is that sometimes both HR and it teams will get involved in
          the workers platform that's one thing or HR gives into your into their internal communication
          ways, the it, the information about who is gonna start. And then it uses work wise to send in
          the most easy as possible way… to."
          Patrick: "In theory, it, in my opinion, it would not be needed at all because it is for me. It is
          part of onboarding and onboarding is not part of it. Mainly, it mainly is to sign a contract to
          get a person here and to do that stuff. But that sound a different, sorry, okay, candidate."
          Jasper: "That's great actually because that means that by using work wise, you don't need to
          facilitate equipment anymore, right?"
          Patrick: "Yeah, in theory, but they will never do this because they will always say it's an it
          job. Can we click, the product and see how that looks like?"
          Jasper: "So, so… here you see then the products that were assigned to templates for, I just did
          some random products. You can either say that a credits will be deducted from the credit or a
          society person or just, the price our dollars you bounce. Then you click the products that you
          want to send."
          Patrick: "Can we have for example… multiple products into one selection?"
          Jasper: "Yep. We can also do multiple products into one box if it's an onboarding box, for
          example, that's something that we can do. Okay. So then you click on add products per order,
          then fill in the house address. So you need to it yourself or the product it's Ray in there. And
          then it's shit."
          Patrick: "Is that shipping information theoretically coming from workday when the
          integration is set up?"
          Jasper: "Be, could be okay. Yeah. Could be, if your workday allows for that, then it can be
          put in there. Is that something, that would help you?"
          Patrick: "Well, are information, that we don't need to double type somewhere helps in my
          opinion."
          Jasper: "Yeah. No, for sure. No, that's also why we have started making integration with these
          HRS systems because that's yeah, making the process as easy as possible again. Yeah, but I
          also want to show you actually how it would look like if an employee would order but not
          sure if that would be the case for you then, but you never know."
          Patrick: "Beginning for sure. Not, but interesting to see anyways."
          Jasper: "Not, so… we can."
          Patrick: "Design by the way, overall work wise, overall, the website looks good, modern
          platform. It's modern. It's good."
          Jasper: "Great to hear. Thank you so much. So, so what we also do here is we can white label
          it. Now, you start with this page where we can also with an announcement page in which,
          yeah, just the basic ideas are mentioned, for example. And then, yeah, this is a personalized
          catalog or web shop for this employee. So these products are not assigned to this employee.
          You can also say only four products will be assigned or a much broader selection whatever
          you want. Then a monthly end or purchase budget are listed here or even the credits as
          possible. Yeah. And then just as a regular web shop, the employee clicks item that he or she
          wants based on the selection… proceed to check out. And here then also, the address details
          can be filled in what?"
          Patrick: "Three three questions. So the help section on the left hand side, can we customize
          that so that we can get rid of chat and mail?"
          Jasper: "Sorry, what do you mean? Exactly?"
          Patrick: "So on the left hand side, there's navigation with application shop, order your home
          office help chat at an mail. Yeah. Is this something that we can hide for employees?"
          Jasper: "I could ask that. I could ask that. It's it's why would you want to hide that as
          actually?"
          Patrick: "Because I just simply want them to, do, I don't want them to chat in here. I don't
          want them, to visit F as in here."
          Jasper: "Okay. Do you just want to have then the most simple way of doing things?"
          Patrick: "Yeah. And because then the second question would be, is this something that can be
          integrated for, or is it planned probably not yet there, but is it planned to have a Microsoft
          teams app that's called work wise that shows this kind of in an I frame or whatever. Probably
          not in an I frame because you need to do this then properly, if you want to have a Microsoft
          teams app, because that would be then a small thing to."
          Jasper: "I haven't heard about this yet, not really. It's so, so what I want to ask you?"
          Patrick: "Okay. Give me one second. I saw you."
          Jasper: "Yeah, but, we are very open to such ideas. So that's something that's I want to.
          Should I just stop sharing my screen?"
          Patrick: "Give me here, just a second. I need to load, but I'll show you then. Yeah, I'll share
          my screen because this is, I'm always thinking of how can a product no matter which product,
          if it's a product that Liam or a different one can become better. And… also by meaning
          better… being more let's say… bring more value to you also when you're sharing something
          with your potential customers. Yep. So do you see my screen? You see Microsoft teams?
          Yes. All right. So in Microsoft teams, so we are currently on a call, right? In Microsoft teams,
          but in Microsoft teams, you have something that is called apps and these apps are apps that
          are it's like an app store, right? It's an app store from Microsoft where they offer different
          applications to you. And there are applications that are from Microsoft and there are
          applications from others, as you see there's Pauli, there is gracloud, there is, whatever
          confluence. I don't know quite a bunch of things."
          Jasper: "We are already using quite a bunch of these, which is quite interesting."
          Patrick: "Exactly. So the ideal situation for me would be let's say orchestra as an example.
          The user clicks on here. It has to work wise logo or whatever. And it says work wise. And
          then I have the view as the employee and I can do exactly what you showed me. Just there
          can do here rather than going to whatever URL and going in here. I just have like work wise
          here and could even rename it to whatever equipment order stuff. And I do it directly in here
          which would help the user to stay in the platform that he's used to. But still using work wise
          as a product?"
          Jasper: "Is actually sounds extremely interesting. Really something that I will be pitching to
          my, to our cto. Do you mind if I take a snippet out of this file Gong which I then forward to
          him?"
          Patrick: "Yeah. But then give me just one second I need to refresh. So the orchestra logo is
          loading so you can take it proper. Sometimes it doesn't load."
          Patrick: "But you can take screenshot here if that helps."
          Jasper: "Yeah. This is, really nice… and definitely something that I would also foresee as us.
          So we are now already thinking of how we can work some integrated in JIRA, in service now
          to make also, the extra step of going to the platform as limited as possible because that's
          needs also a reason, for people to do not work with it or not work as much with it as we want.
          So that's even something that is interesting. And, I wasn't aware of this, but I will definitely
          ask if this is something on a road map already."
          Patrick: "You see, I just give you a quick demo here. So orchestra is a tool we are using to
          create Microsoft teams, right? So, you know, Microsoft teams from what I heard, but if you
          have not a process in place, it gets all over the place. So we have hundreds of Microsoft
          teams. So you don't know what is accurate anymore and stuff like that. So this is where a tool
          like orchestra comes in where you can define what you want to offer. So, I, we decided we
          want to offer a public team and a private team. Then the user clicks on continue, enters the
          name and is doing kind of the order for a new workspace, right? The same he would do for
          your case, actual order for equipment and what we also, because as I'm an administrator, I
          have also something that's called orchestry management. So I can switch between the
          employee view and the management view. So that is something that in your case would also
          be then in my opinion very helpful to have like a tap that is only visible for or visible for all
          employees. And a tap that is something you need to program. Obviously then as part of this
          that is then available to the people that have administrative rights. So work wise could be
          then used entirely in Microsoft teams rather than going, to the URL or… different places."
          Jasper: "Interesting. Would that also be vital for you, to start working with work wise that it's
          integrating integrated in your teams or not necessarily in the first place?"
          Patrick: "It's not vital but everything that makes people, you know how it is, right? So I saw
          your Mac. You have hundreds of applications also open same same here. Every company has
          every user has, they have slack there's mail there's teams. Then there's another Zoom call
          because you need to talk to, you ask people and they like Zoom, they don't like teams. And
          then you have to have work wise, then you have service now then and every time you have
          either need to create a new tab and a browser or you need to open a new application. Yeah.
          And at some point you're the situation is so messed up that you don't know where to find all
          the things. And also, you don't know if there is an application in your company already to do
          the job. Yep. So when the application is already integrated in a tool that most people or 51
          percent of the people are using is easy. It's easy to sell from your point of view. Because you
          can sell look, people don't need to worry about where to find it. You can easily integrate it in
          mix of teams, which is a plus in my opinion from sales point of view. And also for the
          administrative, they can go at the same place and they can do it directly in mix of teams. For
          example, helps for onboarding, helps for ease of use, helps for training and helps you
          ultimately for sales. Just."
          Jasper: "Amazing feedback. Thank you for that at sure. Really nice. Definitely something that
          I will take with me after this call. All right. And indeed, that's also something, how we really
          want to work, improve, the process internally, but also externally. So definitely. Yeah. Okay.
          So yeah, there was one thing I wanted to show you more. So going back to the employer side
          in the asset management tool. But last time you mentioned asset management was not very
          much relevant for you because you're already using everything in servers now, right? For
          asset management?"
          Patrick: "We do, but you can share it with me. But one quick question first, my camera seems
          to be frozen in Microsoft teams and I don't see you anymore. I'm not sure if that is also for
          you to get the case."
          Jasper: "Yeah. Now I see you again, you see me again. Perfect. So I will just, this is only, this
          only would take like a minute. So some companies indeed want to continue using their own
          asset management tool. If everything is going well and in order, some companies want to
          replace for work wise, how it would look, we would look for us. If so, in the case of work
          wise is like you see just the overview of all the employees within the company… then I can
          manage assets. You see exactly which person has, which assets when it has been ordered,
          what the original value was. We can also put in the appreciation values there. If it's for rental
          item, you can see and the rental date is ended. So you also know, when an automatic email
          that sense when, yeah, the rental needs to be renewed or not. And we can also add in all the
          existing assets so we can do that per person or we can do that. Of course, I, a bulk so that
          everyone has the assets centrally put the platform. And yeah, if you want to off board assets,
          then usually, you have the button here. Now, I don't see it because it's taken off for this
          accounts. But then you can off board the assets and then you click on the assets that you want
          to off board. And then… we will make sure that it's picked up stored in a warehouse and set
          for the new hire again. So that's how we would do, the decommissioning and the off boarding
          parts? So."
          Patrick: "Okay."
          Jasper: "Yeah. It, it has been now going a little bit back and forth between different things.
          But I hope I have now."
          Patrick: "With…"
          Jasper: "How we do the entire equipment life cycle. So from start until when people leave
          again. And also, the daily asset management."
          Patrick: "Question, for the order stuff and even for the off boarding, the button that is Cory
          not showing. Is there a way that… I don't know to attach a workflow is something that it
          creates the servers now ticket?"
          Jasper: "Yes, this is something that can be done. And we also discussed this before with our
          tech team. The only thing I would need to know is how you would like to have that sketched
          out. So I can ask how we can make that ticketing. So I can now say, yes, we can do it, but of
          course, I need to have, the very specific requirements, how that would work. And yeah, how
          far that integration would go?"
          Patrick: "Okay. Because that is similar to micro teams integration. I would say for many
          super small startups, they don't have a CM DB or asset management, but for many other
          companies, they have some sort of either CM DB or service now. And the integration there is
          similar to the workday, right?"
          Jasper: "Exactly."
          Patrick: "Okay. So from, I saw from the information that you sent that there are three
          different kinds of seats and the seats are let's say we have 100 basic seats. If an employee gets
          off boarded, the seat is not used and it's kind of 10 on hold. But it's still something that is part,
          of the payment, then it's not like if there's no user assigned, there's no payment. It is, if there
          is a seat, it is paid, it needs to get paid, right?"
          Jasper: "Yeah. So you pay for the minimum seats. And then indeed, when there's a new one,
          it got new person coming. Then that seat will be taken up. So there won't be an extra seat, but
          that's is the need the same seats as you have been paying for you?"
          Patrick: "Okay. Set up a stock, okay? Configuration service of it equipment, all devices set up
          to me. Okay? So the configuration service for it equipment would mean that only if a seat
          has, then the proceed, it can be added automatically into our MDM?"
          Jasper: "Yes. But if you would that's something that we can discuss. So you see that falls
          under, the pro package. But if you really would like to go for the basic package and only do
          the MDM integration, then, we can make an exception there. But if I hear it, I think that the
          enterprise package would anyways be the option for you with sso and workday integrations,
          or would you rather start with a per seat? Like a basic or pro package? And then in a rolling
          approach ads with other features later on."
          Patrick: "It depends a little bit on price. And also as I said, from the current thought process,
          this is a solution that could solve the thing like it should be, in, if you would set this up from
          scratch. This would be a good point but we are not there anymore and we are in a situation
          where the roles are a little bit kind of fixed even though they shouldn't be. The perception is I,
          it needs to order and do onboarding off boarding for it equipment. It is what it is. So there are
          a few things that are… not that easy to change anymore, as it should be maybe in the
          beginning. So I just wanna check what as is because if there are in the end are four people in
          it that need to ship things around left and right? I don't need. So, right? I need, so if I have an
          employee that wants to order something then it makes sense or if I have let's say 20 or 30
          people, but other than that doesn't make sense, but it's not needed for workday same. I don't
          need workday if the ticket anyways comes into our service now and then we are starting from
          there, right? But… MDM inclusion always needs to happen no matter what company branded
          environment is also something that if the employee is using it. Sure that is key, right? Yeah.
          Then custom reports also. So I'm not so sure if enterprise is, would be necessarily needed for,
          or if this is kind of, the criteria that would be for us key. I don't think so. But the MDM thing
          would be key because we are managing our equipment in TUNE and also, the buffer stock if
          it depends then a little bit on what the non buffer stock availability and timeline looks like,
          right? So if that means obviously, it takes six weeks then what the heck? Right? Then you
          need it obviously. But if it is two to five days, what you or what I at least on the demo, then it
          is, I think more or less, okay."
          Jasper: "But what I would foresee is the biggest difference between the pro and the basic
          package is that for the pro package, we also allow for retrieving assets. So also making use of
          our warehousing system. So we are having warehousing in Europe. We have warehouse in
          UK. We have warehousing us. And with the pro package, you allow us to be using the
          warehouse for your assets. So in the basic package, we don't do that. So then I would say if
          you want to have the full equipment life cycle including the off boarding parts, then the pro
          package would be part of it. And then, yeah, MDM usually falls in that's also more easily."
          Patrick: "And it's also says 500 bucks monthly platform fee. So it is 500 bucks. So if let's say
          pro, the minimum pro would be 509 euro because there needs to be at least one seat and the
          monthly platform fee?"
          Jasper: "Yes, but the minimum number of seats, in the document is has as 50, but we can also
          do it with the minimum of 20. But we always said 20, is, the least minimum, yeah."
          Patrick: "Okay. I think, I know now how this, how it could work. Obviously pricing of the
          equipment is key, right? So if the pricing of the equipment is, I don't know… 20 percent more
          expensive than we are getting from base right now, then it is 20 percent more plus 10 tenure
          or per user per month. Also right? That is that is an office three takes five license for
          something that is needed. Let's say onboarding, one support case and off boarding. So let's
          say a user needs or an employee needs Workwize platform three times… and maybe… even
          only one time himself or herself. Because the first onboarding is done by someone else and
          off boarding also. So it is 10 euros per month, which is, I would say even in almost an office
          six five suite license and they're using it once, in their time with William. So, this means that
          it, well, the equipment that is part of the catalogue… has to be good in price."
          Jasper: "Makes sense. Yep. For sure. So our aim is also to have it in market pricing, of
          course, per region. It might differ. But I can give you insights in the product prices from last
          time. I understood you also want to have a comparison between rental and purchase of
          products or is it only purchase?"
          Patrick: "I would say, I would say what is more beneficial overall currently with the other
          partners, we are requesting kind of a similar situation. We are doing renting?"
          Jasper: "If, if you're conscious of price, I would always say go for purchasing. If you're
          conscious of the flexibility in regards to catalogues. I would also say always go for
          purchasing. It makes the workflow always easier. It gives you a much broader spectre of
          products that you can go for and it's cheaper on the long term. So, I would always say go for
          purchase. But perhaps it doesn't matter when body you go for purchase rental. So I can give
          you pricing for both purchase and rental. If that's something that you would like to see."
          Patrick: "Yeah, it would be good to see. Yes."
          Jasper: "Yep. So the other parts that other companies that you're not talking to were mainly
          suppliers, do they have? Are they quite similar to what I just showed you or, is it
          completely?"
          Patrick: "Yeah. So we are doing this with base. I think I told you last time and we're also
          doing this with telecom. And there we are looking for or currently, we are not there yet. But
          the idea is that as mentioned in the beginning, we have kind of an email address, Jasper at
          telecom and we say, hey, Jasper, there is a new person coming. It is first name, I second name
          whatever address template to let's go. And then Jasper is doing whatever he needs to do and
          this is done for us then. And the same for the support and the same for the off boarding.
          Okay? And the benefit quite frankly is we are have a telecom contract. So our mobile devices
          are from telecom and the phones are also coming from them. So when we're doing, we're
          considering a package deal with them. We have everything. So we have the phone, we have,
          the laptop, the back, the mouse, the bluetooth headset. And then we are going for everyone
          has or we are doing iPhone only and we are then going for iPhone including E Sim, not even
          physical Sim anymore, which is helpful for them and helpful for us. The downside for either
          ball or you would be that the phone is not included because we have phone exclusive a
          telecom and the phone always needs to be something separate, right? Because we need to
          reach out to telecom. Say, hey, we need a new phone for I at this place. And for telecom, we
          could say that when we're doing everything with them, we're saying, hey, I whole package."
          Jasper: "Would you think that if you're telephone exclusive or phone exclusive with them,
          that's using them as a supplier in the work wise platform? Would that be an option so that you
          say, okay, if a phone, is purchased for anyone, in that will also be done for work wise? And
          telecom was again the duct telecom or is then part of our suppliers?"
          Patrick: "Sure. That would be also than an option for sure. I'm not sure if they would be open
          to that to do that because that's then something that we're work wise and telecom needs to talk
          to each other, right? But this is also something for again, not like a wishful thinking but
          something that I could be relevant for many of your potential customers to have a relationship
          with, the big let's say phone companies with a phone, telecom, EEBT in the U. K, Swiss
          comb in Switzerland because we are with, in Switzerland, we are swim in the UK. We are
          with EERT. In Germany. We are with dotcom, and in the US. With verizon… because an
          onboarding package, if the everyone has a phone by now, right? And most employees
          because it's also used for a second factor authentication. So it, I would say 90 percent at least
          for fixed internal employees, not first line workers, but fixed internal employees get and
          phone. So to have the integration to say, okay, the onboarding package includes also the
          phone and work wise is taking care of the kind of relationship with that partner would be
          even more selling point, for work wise versus others."
          Jasper: "That's something that, we can accommodate. So that's something, what we've also
          done for other companies who were having certain agreements with their suppliers, which is
          why we didn't have a chat. We had to integrate them, which also made us open to, these
          partnerships. Only thing is of course, that we do need to have a mutual cooperation. Both
          parties need to be open to that. So that's…"
          Patrick: "I think we…"
          Jasper: "Can look into. We can also look into that in the face too. So we can also start with a
          certain package that excludes phones and always see if we can make it easier to integrate
          them. And then with them, I mean these suppliers or vendors for that. Yeah. So, what would
          you say as a, as a next step? So how would you see the following process going? You, you,
          you'd like to have it all sketched out quite?"
          Patrick: "Yeah, I need prices that's the next thing I need from you guys… because I can go to
          business, enter my management and say, hey, there's work, but they say, well, that's nice.
          You can call them whatever you want. But we need to see price, right? And it's also not too
          important for them right now to have an understanding of how the solution in the process
          looks like it's important, for me right now. So I can think of who is going to act with that
          platform. The platform. It's not a platform, right? The way I described to you with one is a
          way that can never be with an employee because it's writing an email and doing something.
          It, it is not a process. It's just shit. So, right? But the product, the platform, the Workwize
          platform, where we gonna call it is something that you can give to employees. So when it
          comes down to pricing and to compare feature and say, hey, look, work wise cannot make a
          template with the phone because telecom does not want to work with them together or
          whatever. Then we can still say, okay, so this is the downside of work wise and, but they
          have the upside of having the employee work with the platform if needed. And we can think
          of the whole let's say the hardware catalog that we want to offer because we do not currently
          offer a hardware catalogue at any place at la. So this is something that is currently in our
          minds planned in service now, and many companies are doing this in service now. But this is
          kind of where work wise would then be the competition to service now where hardware could
          be purchased or ordered in the work wise platform. But again, it needs to be then integrated
          into service. Now, raising a ticket and whatnot. But this is then, where, the nuances come.
          Say, okay, this is price here, but this is price here. This has the features here. This has the
          features there."
          Jasper: "Clear. So I understand that, you need to have a better scope of pricing both in terms
          of the SaaS fee as well as the product fee. I can provide that you have already send me, the
          product details. So I can for sure send you a comparison between rental, and merging there.
          Although as purchasing for the other parts, how we gonna constitute work wise together with
          you? That's that is still flexible. So I would say, would it be then an idea to give you an
          overview for a basic package of employees outside Germany? Or do you want to have, the
          full company in there? What, what is the best thing to send to you as a quotation?"
          Patrick: "I would say."
          Patrick: "To make it?"
          Jasper: "Or, yeah."
          Patrick: "To make it… quick question first if you would go with the minimum 20 seats and
          the whatever the 500 bucks per month. And… I haven't have a new hire and that new hire
          does not have a seat because let's say the 20 seats are reserved for it. And for HR people, I
          cannot even do that, right? I need every employee that needs to get shipment needs to have a
          seat, right?"
          Jasper: "Yes, that person needs to have a…"
          Patrick: "C, yeah. Okay. Then you need to calculate."
          Jasper: "What you can do, you can also then deactivate the seat. Don't have an idea of where
          the assets are in Workwize, but then use that seat for another new hire. But then you can offer
          that person anymore. If I work, that's the only thing, but."
          Patrick: "But then I, okay. But this is kind of then where creativity comes to play like for
          every licensing stuff, right? So then I would just keep two licenses there or five. And when
          there's a new off boarding, I'll give them the seats and do them the off boarding. And I'll
          always switch left and right? Yeah, sure. But this is."
          Jasper: "Rate, you can do it, but that will take you quite a lot of manual work. And I think
          that's also not how, the beauty of work wise then comes in terms of the automation that you
          can do, but."
          Patrick: "Hey, you?"
          Jasper: "You could, you could work with that?"
          Patrick: "Okay. So, the number you need to calculate with is 100 seats."
          Jasper: "For the, or basic package?"
          Patrick: "That's a good question."
          Patrick: "How much roughly is the difference between enterprise and pro per."
          Jasper: "Between two and five depends. So the enterprise package for small companies, 15
          years per user, for more users in is 12 years per user."
          Patrick: "Because that is quite a difference then, right? Because that's from let's say versus
          enterprise and basic, this than double the price?"
          Jasper: "Yeah. Because of course, you have the integrations you have the customizations you
          have the?"
          Patrick: "That we would need pro anyways, if we want to do off boarding. Yeah. But it's still
          then 50 percent."
          Jasper: "50 percent."
          Patrick: "Towards lower versus enterprise?"
          Jasper: "Yes, but of course, I'm in charge, of making quotation. And I can also do something
          about the enterprise package. So I can also, in regards to, the growth perspective of Lydia."
          Patrick: "Let's do the following."
          Jasper: "Any more people in there? I can always say, let's make a smaller seat size or smaller
          seat price for enterprise for him. If we know that over time, we can work and iterate more
          parts of the company and, we continue doing this."
          Patrick: "Let's do the following. We're going with 101 100 seats enterprise. Yeah. Okay."
          Jasper: "Perfect."
          Patrick: "Because then, I know what is kind of, the max paint scenario?"
          Jasper: "Yeah. All right. That's fine. Then I will make a price for you. I will send it to you
          and I will do that on a Monday. If that's okay for you, then you have everything."
          Patrick: "On a Tuesday. So, because we are still waiting for telecom, let me quickly, give me
          one minute because I have the telco meeting… with them on Wednesday. So Wednesday
          would be fine anyways also. So no need to rush."
          Jasper: "Okay. Well, I will take my time but I will try Monday or Tuesday morning then."
          Patrick: "Also take Wednesday if the pricing gets better, if that helps."
          Jasper: "All right. If, if you can decide quickly, I can always do something about price, you
          know what though, but yeah, what do you think? So? When do you, would you like to make a
          decision between the different vendors? So, is it something?"
          Patrick: "We need to get all the pricing right? But I would say I would like to have this as
          soon as possible. And, but I don't I'm not so 100 percent sure yet. My manager is gone until
          the end of may. I hope we could get something done by the end of June. I don't know if that is
          realistic… but, yeah."
          Jasper: "That is something that I would also hope that we can get something done before the
          end of June, maybe to be fully transparent with you. We are now approaching a series a
          funding meeting that we need to have very cool clients especially some more from Germany.
          And I, is of course, very high on our list because it's exactly the sort of client that we want to
          serve in terms of growth in terms of geographic coverage in terms of company size. So I
          think I can do something I can discuss with my manager. Of course, if I can give something
          extra in terms of pricing, if we can finish this in June, that's something I could already email
          you on the Tuesday or on the Wednesday. So yeah, maybe you can take that into
          consideration that we can work on a timeline of end of June with maybe some extra, yeah,
          something towards you."
          Patrick: "Series a funding is nice. We have done that also obviously."
          Jasper: "But quite some time ago already and not, we are not, we are not in the series E
          already, but I think you had series."
          Patrick: "You get there, you get there."
          Jasper: "Yeah, we'll…"
          Patrick: "We'll get there. And at some point you'll also ring the bell on the New York stock
          exchange and then everything gets more complicated. I can tell you."
          Jasper: "Life is done."
          Patrick: "Life gets more complicated."
          Jasper: "Yeah, yeah, yeah, yeah, for sure. But are you listed, are you listed?"
          Patrick: "Yeah, we are now getting back a little bit over one us dollar because we had 200
          and where we had kind of a big investment from a partner we're working with and
          250,000,000, which is nice it helps."
          Jasper: "But that's for you. Of course, a lot of manufacturing. Now, it's a lot of."
          Patrick: "Because, we are starting, so jet, we're the official jet gets built this year. So we're
          starting building the official get this year. And for that, you need, we need to build the whole.
          So I'm looking there, this is kind of the hanger where our production line will be in. And if
          you have ever seen kind of a car production line, it's not a car we are building, right? But it is,
          you also need to have all this crazy equipment and."
          Jasper: "Yeah. I'm actually quite curious how everything looks like, but let's make this, if
          that's okay for you, if we would start working together? I'm happy, to drop by and see, the
          factory because I think it's super, it's huge, but maybe that's not for now, but I would be very
          interested in that."
          Patrick: "Everyone is, the chat is in there in the hangeror, the chat and everyone, all our
          partners, when they're coming inside, we always take them for lunch. We're having their use
          kind of there from eight to 12 talking about relationship partnership. You, they all go for
          lunch together because we have also lunch here on site like fancy start up with people
          cooking and you see them cooking and stuff like that. And then after lunch, we are taking the
          partners to the show chat and take pictures. So this is something that could await you also."
          Jasper: "Maybe I should think twice about the offer that I'm gonna make."
          Patrick: "Let's see and I have."
          Jasper: "Is internally well as possible but yeah, hopefully, we can move on to the next steps
          soon."
          Patrick: "I'll just send you something quickly. Also in the chat, what we talked about, the
          third party app and micros of teams, that is the link to, the micro site about third party apps.
          Yup."
          Jasper: "All right. Great. Patrick. It was, it was a pleasure to speak to you again. I will send
          everything to you if you have any questions before or after, just email me. Should we put
          something in the agenda after your manager is back or in between already? What do you
          think?"
          Patrick: "I need to wait until he's back because then I would hopefully have to have pricing
          from telecom and you guys and I would then present something to him and then re, go from
          there."
          Jasper: "Should I do that then on the, I think the second of June is two weeks from now?"
          Patrick: "Yeah, he's coming back on the first of June. Maybe you can put in if you want, you
          can put in something on the seventh of June."
          Jasper: "Yeah, yeah, I will do that. Yeah, I will say what we need."
          Patrick: "The time. Yeah, perfect."
          Jasper: "Great. Patrick. And yeah, if you have something before ready, you would like to
          share it and we can already do that. Of course. But thank you so much for the inputs and your
          feedback and have a lovely weekend and speak to you in two weeks and…"
          Patrick: "Same. Thank you very much. Have a good."
          Jasper: "Right, Joe. Bye bye."
          Link to snippet
      """

print("Splitting text into chunks...")
text_chunks = split_text_into_chunks(text)

print("Creating embeddings...")
embeddings = [(uuid.uuid4().hex, create_embedding(chunk), {"text": chunk}) for chunk in text_chunks]

print("Embeddings created.")

query = """This is a conversation between a sales team member at Workwize and a potential customer. The customer is interested in buying our SaaS product Workwize. Could you give a detailed description of any product feedback or improvements the potential customer gives. Also, could you provide a list of keywords that are related to his product needs.
    """

print("Creating query embedding...")
query_embedding = create_query_embedding(query)

num_results = 7
results = [(cosine_similarity([query_embedding], [embedding])[0][0], id, meta) for id, embedding, meta in embeddings]

print("Sorting results...")
results.sort(reverse=True)

print("Top results:")
for score, id, meta in results[:num_results]:
    print(f"Text chunk: {meta['text']}")
    print(f"Similarity score: {score}")
    print()

print("Generating answer using the GPT3.5 turbo model...")
context = " ".join([meta['text'] for _, _, meta in results[:num_results]])

prompt = f"""
Context: {context}
Question: {query}
"""

def create_chat_completion():
    return openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a product manager giving structured product insights to us."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=1024,
        temperature=1,
    )

response = retry_openai_request(create_chat_completion)

print("Question:", query)
print("Answer:")
print(response['choices'][0]['message']['content'].strip())

query = "This is a conversation between a sales team member at Workwize and a potential customer. Could you derive if the customer received a business case and whether it was discussed."

prompt = f"""
Context: {context}
Question: {query}
"""

def create_chat_completion():
    return openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a sales manager"},
            {"role": "user", "content": prompt}
        ],
        max_tokens=1024,
        temperature=1,
    )
response = retry_openai_request(create_chat_completion)

print("Question:", query)
print("Answer:")
print(response['choices'][0]['message']['content'].strip())

query = "This is a conversation between a sales team member at Workwize and a potential customer. Could you give insights into what the next steps are that are discussed in the call, structured concisely in a few bullet points"

prompt = f"""
Context: {context}
Question: {query}
"""

def create_chat_completion():
    return openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a sales manager"},
            {"role": "user", "content": prompt}
        ],
        max_tokens=1024,
        temperature=1,
    )


response = retry_openai_request(create_chat_completion)
print("Question:", query)
print("Answer:")
print(response['choices'][0]['message']['content'].strip())
# print(response['choices'][0]['text'].strip())
